describe('Send Email', () => {
    it('passes', () => {
      cy.visit('https://www.geniusgiant.com/')
    })

    it('scroll to the bottom,', () => {
        cy.scrollTo ('bottom')
      })

   it('Input Name,', () => {
       cy.get ('input[type="text"]')
       .type ('Almighty Bruce')
      })

      it('Input Email,', () => {
        cy.get ('input[type="email"]')
        .type ('pakyu@gmail.com')
       })  

       it('Input Message,', () => {
        cy.get ('textarea[id="message"]')
        .type ('Ako si Jaimeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee')
       })   

       it('Click Submit,', () => {
        cy.get ('button[type="submit"]')
        .click() 
       })   

  })