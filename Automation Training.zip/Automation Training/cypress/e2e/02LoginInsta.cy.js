describe('Visit Instagram', () => {
    it('passes', () => {
      cy.visit('https://www.instagram.com/')
    })

    // it('Login via Facebook,', () => {
    //     cy.get ('button[type="button"]')
    //     .click() 
    //    })

    //    FAILED

    it('Input Email,', () => {
        cy.get ('input[type="text"]')
        .type ('jursuajrii@gmail.commmmmm')
       })  
    
    it('Check Login Button if enabled/disabled,', () => {
        cy.get ('button[type="submit"]')
        .should('be.disabled') 
       })  

   it('Input Password,', () => {
        cy.get ('input[type="password"]')
        .type ('jordison011111111')
       })     

       it('Submit Login Attempt,', () => {
        cy.get ('button[type="submit"]')
        .click()
       })  
      
       it('Verify Error Message,', () => {
        cy.get ('#slfErrorAlert')
        .should('be.visible')
       })    











  })

